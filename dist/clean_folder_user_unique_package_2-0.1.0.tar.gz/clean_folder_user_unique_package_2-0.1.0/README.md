This package will start files and remove empty folders.
